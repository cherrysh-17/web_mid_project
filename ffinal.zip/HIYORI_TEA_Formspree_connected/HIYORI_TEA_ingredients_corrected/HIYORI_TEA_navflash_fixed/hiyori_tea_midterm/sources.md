# 來源與使用說明

## 圖片
| 檔案 | 用途 | 來源 |
|---|---|---|
| assets/logo.png | 品牌 Logo（C 方案） | 由專題作者提供 |
| assets/peach-oolong.jpg、peach-detail.jpg | 蜜桃烏龍照片與細節裁切 | 由專題作者提供；**請補上原始出處與授權** |
| assets/strawberry-milk.jpg、strawberry-detail.jpg | 草莓雲朵鮮奶照片與細節裁切 | 由專題作者提供；**請補上原始出處與授權** |
| assets/matcha-latte.jpg | 靜岡抹茶拿鐵照片 | 由專題作者提供；**請補上原始出處與授權** |
| assets/passion-lime.jpg、passion-detail.jpg | 百香青檸綠茶照片與細節裁切 | 由專題作者提供；**請補上原始出處與授權** |
| assets/pearl-milk.svg | 黑糖珍珠鮮奶示意插畫 | AI（Claude）協助以 SVG 程式碼繪製，2026-10-30 |
| assets/news-opening.svg、news-member.svg | 消息示意插畫 | AI（Claude）協助以 SVG 程式碼繪製，2026-10-30 |
| assets/screens/*.jpg | 三方案六張截圖 | 由本站頁面截圖產生 |
| 版面概念 | 鮮茶道 Presotea 官網飲品頁（presotea.com/drinks） | 僅參考版型想法（滿版主視覺、吊牌、分類標籤、直式標籤卡）；未使用其圖片、文字、圖示或程式碼 |

## 字體
Noto Serif TC、Noto Sans TC、DM Sans，來自 Google Fonts（SIL Open Font License）。

## 文字與資料
品牌文案、人物、活動、財務數據皆為虛構，由專題企劃與 AI 協助撰寫；財務驗算：營業利益＝營收－營業成本－營業費用。

## 程式
首頁 HTML/CSS 為專題作者原作；內頁、替代風格與文件由 AI（Claude）協助擴充。

## 資源清單與壓縮紀錄
見 `design.html` 的「圖片資源與壓縮前後」。
