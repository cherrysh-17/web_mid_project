/* 風格切換：只替換 CSS 主題檔，不改頁面內容。記住選擇於 localStorage。 */
(function () {
  var link = document.getElementById('theme-css');
  if (!link) return;
  var key = 'hiyori-theme';
  var base = link.getAttribute('href').replace(/theme-[abc]\.css.*$/, '');
  var cur = link.getAttribute('data-default') || 'a';
  var saved = null;
  try { saved = localStorage.getItem(key); } catch (e) {}
  var q = (location.search.match(/[?&]theme=([abc])/) || [])[1];
  if (q) { cur = q; try { localStorage.setItem(key, q); } catch (e) {} }
  else if (!link.hasAttribute('data-force') && /^[abc]$/.test(saved || '')) { cur = saved; }
  apply(cur);
  function apply(t) {
    cur = t;
    link.setAttribute('href', base + 'theme-' + t + '.css');
    document.documentElement.setAttribute('data-theme', t);
  }
  document.addEventListener('DOMContentLoaded', function () {
    var names = { a: ['A', '暖色', 'A 日和暖色'], b: ['B', '深色', 'B 夜茶深色'], c: ['C', '幾何', 'C 鮮明幾何'] };
    var box = document.createElement('div');
    box.className = 'theme-switch';
    box.setAttribute('role', 'group');
    box.setAttribute('aria-label', '切換網站風格');
    var label = document.createElement('span');
    label.textContent = 'STYLE';
    box.appendChild(label);
    var buttons = {};
    ['a', 'b', 'c'].forEach(function (t) {
      var b = document.createElement('button');
      b.type = 'button';
      b.textContent = names[t][0] + ' ' + names[t][1];
      b.setAttribute('aria-label', '切換為風格 ' + names[t][2]);
      b.setAttribute('aria-pressed', String(t === cur));
      b.addEventListener('click', function () {
        apply(t);
        try { localStorage.setItem(key, t); } catch (e) {}
        Object.keys(buttons).forEach(function (k) { buttons[k].setAttribute('aria-pressed', String(k === t)); });
      });
      buttons[t] = b;
      box.appendChild(b);
    });
    document.body.appendChild(box);
  });
})();
