# 日和茶作 HIYORI TEA — 網頁程式設計期中專題

虛構茶飲品牌「日和茶作」的公司網站。品牌、人物、價格、活動、財務與消息皆為課程專題虛構設定。

## 開啟方式
解壓縮後用瀏覽器開啟 `index.html`（建議保持資料夾結構）。字體使用 Google Fonts，需連網才會顯示指定字體，離線時使用系統字體。

## 檔案
- 主要頁面（8）：`index.html`、`about.html`、`products.html`、`team.html`、`calendar.html`、`finance.html`、`news.html`、`feedback.html`
- 產品詳細頁（2）：`product-01.html`（蜜桃烏龍）、`product-02.html`（草莓雲朵鮮奶）
- 其他：`design.html`（設計比較與決策）、`feedback-preview.html`（表單預覽頁）
- 替代首頁：`variants/dark/index.html`（方案 B）、`variants/bold/index.html`（方案 C）
- 樣式：`styles/base.css`（共用結構與元件，變數驅動）、`styles/theme-a.css`／`theme-b.css`／`theme-c.css`（三種風格）、`styles/switcher.js`（風格切換按鈕）

## 風格切換（A／B／C）
同一份 HTML，只換 CSS 主題檔。每頁右下角「STYLE」按鈕可切換，選擇存在瀏覽器 localStorage、全站套用；也可用網址 `?theme=a|b|c` 指定。各頁 `<head>` 只多了一個 `id="theme-css"` 的 link 與一行 `switcher.js`。
- 資源：`assets/`（照片、SVG、六張截圖 `assets/screens/`）
- 文件：`sources.md`、`ai-log.md`、`test-log.md`

## 內容對照
- Logo：C 方案，英文極簡字標 `HIYORI TEA`（沿用提供的 logo.png，未重新設計）
- 四杯主打：蜜桃烏龍 NT$65、草莓雲朵鮮奶 NT$75、靜岡抹茶拿鐵 NT$70、百香青檸綠茶 NT$60；茶單另有黑糖珍珠鮮奶 NT$70（滿足至少五項產品）
- 最新消息：2026.04.15 蜜桃烏龍正式上市／2026.04.01 春季會員集點活動開跑／2026.03.20 日和茶作正式開幕
- 行事曆：2026年11月（11/1 為週日）六項活動
- 財務：2026年4–9月簡化營業損益（單位：新臺幣萬元）

## 表單
`feedback.html` 為靜態展示版，使用 GET 導向 `feedback-preview.html`，不保存也不寄送資料。
